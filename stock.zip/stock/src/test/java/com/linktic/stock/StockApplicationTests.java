package com.linktic.stock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StockApplicationTests {

	@Test
	void contextLoads() {
	}

}
